package com.lab.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPageFactory {

	WebDriver driver;
	//identify the Elements
	@FindBy(name="uname")
	@CacheLookup
	WebElement userName;
	
	@FindBy(name="pwd")
	@CacheLookup
	WebElement password;
	
	@FindBy(name="errmsg")
	@CacheLookup
	WebElement errorMessage;
	
	@FindBy(className="btn")
	@CacheLookup
	WebElement loginButton;
	
	//constructor
	public LoginPageFactory(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}

	//getter and setter
	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public String getUserName() {
		return userName.getAttribute("value");
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}
		
	public String getPassword() {
		return password.getAttribute("value");
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);;
	}

	public String getErrorMessage() {
		return errorMessage.getAttribute("value");
	}

	public void setErrorMessage(String errorMessage) {
		this.errorMessage.sendKeys(errorMessage);;
	}

	public WebElement getLoginButton() {
		return loginButton;
	}

	public void setLoginButton() {
		this.loginButton.click();
	}
	
	
}
